This folder conatins all elements of the final code from group 2 of the TRUSS project of the course CEGM2003.

In order to run the computation without all the print statements, some of the source code was modified, see "Source code modification.docx"

In the folder "truss_bridge" our final model, called "Bayesian_optimization_final.ipynb" is included, all analyses shown during the presentation were performed with this notebook.

Sincerly, 

TRUSS 2