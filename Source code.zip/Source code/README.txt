Replace the files in the source code with the files from the zip file. 
The files are located in the following folder:

------------------------------------------------------------

main.py -> Truss_project/main.py

initmodule.py -> Truss_project/modules/initmodule.py

modeshapemodule.py -> Truss_project/modules/modeshapemodule.py

paramshapes.py -> Truss_project/utils/paramshapes.py

pointmassmodel.py -> Truss_project/models/pointmassmodel.py